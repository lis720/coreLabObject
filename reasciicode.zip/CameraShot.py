# this is the code that will just help you take the camera shot
import io
import time
from twitter import *
import picamera
from ascciConverter import Convertor
import textToImage


RENDER_CHARS = (80, 40)
CAPTURE_RESOLUTION = (1600, 1400)
CAPTURE_RESIZE = tuple(i * 2 for i in RENDER_CHARS)
RENDER_CONTRAST = 56

class Camera:
    def __init__(self):
        self.camera = picamera.PiCamera(resolution=CAPTURE_RESOLUTION)
        self.preview_alpha = 200

    def capture(self):
        stream = io.BytesIO()
        self.camera.capture(stream, 'rgb', resize=CAPTURE_RESIZE)
        stream.seek(0)
        return stream

    def toggle_preview(self):
        if self.camera.preview is None:
            self.start_preview()
        else:
            self.stop_preview()

    def start_preview(self, alpha=255):
        self.camera.start_preview(hflip = True)
        self.camera.preview.alpha = alpha

    def stop_preview(self):
        self.camera.stop_preview()

    def stop(self):
        self.camera.close()


def save_image(img):
    fname = time.strftime("%Y-%m-%d_%H-%M-%S")
    fpath = "image_" + fname
    open(fpath, 'wb').write(img)
    return fpath



def footer_line():
    date = time.strftime("%d/%m/%Y %H.%M:%S")
    return "Good Work", date

#this line here will be capturing the image

CAMERA = Camera()
CAMERA.start_preview()
print("showing the view...")
time.sleep(15)
print("taking image now!...")
time.sleep(3)
stream = CAMERA.capture()
CAMERA.stop_preview()
print("clsoing the camera")
CAMERA.stop()


print("processing the image...")
#Camera shot is taken now I am going to convert the image into a text ascii
image_converter = Convertor(stream_size=CAPTURE_RESIZE, size=RENDER_CHARS, contrast=RENDER_CONTRAST)

text = image_converter.convert(stream)

#now we have the ascci art text
textConvert = textToImage.TextImage('7x13.pil')
print("converting the ascci text to image")

image = textConvert.draw_image(text,footer=footer_line())
image = textToImage.save_image(image).getvalue()

#here we are saving the image only to folder we have
path = save_image(image)

print("Saved Image: " + path)
#making the tweet

print("\n\nMaking the tweet!")

#TWITTER_CONSUMER_KEY="8xbaurNrzCfEjWJxqpbRX0S34"
#TWITTER_CONSUMER_SECRET=“hbZ1P3qyUohxghSBPPttfoVR6RjdrlNkr04rxEIgAoKkCYYHoF"
#TWITTER_ACCESS_TOKEN="938821186494128128-E5sPkhliMfU2EmdHP4rH9OLBG8"
#TWITTER_ACCESS_TOKEN_SECRET=“6jQpZabGAjeyCQ7YoL6SWvATwNbJrkq8QfhxNP"
#OAth arguments are as : 'access_token', 'access_secret', 'consumer_key', 'consumer_secret'
t = Twitter(auth = OAuth('938821186494128128-E5sPkhliMfU2EmdHP4rH9OLBG81xsFS', '6jQpZabGAjeyCQ7YoL6SWvATwNbJrkq8QfhxNPkZrHLRT', '8xbaurNrzCfEjWJxqpbRX0S34', 'hbZ1P3qyUohxghSBPPttfoVR6RjdrlNkr04rxEIgAoKkCYYHoF'))

params = {'media[]': image, 'status': text}
t.statuses.update_with_media(**params)



