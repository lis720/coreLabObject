import aalib
from PIL import Image

class Convertor:
    def __init__(self, stream_size, size=(80, 40), contrast=100):
        width, height = size
        self.stream_size = stream_size
        self.screen = aalib.AsciiScreen(width=width, height=height)
        self.vsize = self.screen.virtual_size
        self.contrast = contrast

    def prepare_image(self, stream):
        return Image.frombytes(data=stream.getvalue(), mode='RGB', size=self.stream_size).convert('L')

    def convert(self, stream):
        screen = self.screen
        image = self.prepare_image(stream)
        screen.put_image((0, 0), image)
        text = screen.render(dithering_mode=aalib.DITHER_FLOYD_STEINBERG, contrast=self.contrast)
        return text